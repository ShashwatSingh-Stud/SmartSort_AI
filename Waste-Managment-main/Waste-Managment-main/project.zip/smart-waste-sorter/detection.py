from __future__ import annotations

import os
import random
import time
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np


@dataclass(frozen=True)
class DetectionResult:
    category: str
    confidence: float
    annotated_frame: np.ndarray
    source: str


def _normalize_label(label: str) -> str:
    s = (label or "").strip().lower()
    if "plastic" in s:
        return "Plastic"
    if "paper" in s:
        return "Paper"
    if "metal" in s or "aluminum" in s or "tin" in s:
        return "Metal"
    if "organic" in s or "compost" in s or "food" in s:
        return "Organic"
    return label.strip()


class WasteClassifier:
    """
    Optional trained classifier.

    Supported:
    - TensorFlow Lite model (.tflite) via `tflite-runtime` / `tensorflow`
    - Teachable Machine / Keras model (.h5/.keras) via `tensorflow`

    Configure with environment variables:
    - `WASTE_MODEL_PATH`: path to .tflite or .h5/.keras
    - `WASTE_LABELS_PATH`: optional labels file (one label per line) for .tflite
    """

    def __init__(self, categories: list[str]) -> None:
        self.categories = categories
        self.model_path = os.environ.get("WASTE_MODEL_PATH", "").strip()
        self.labels_path = os.environ.get("WASTE_LABELS_PATH", "").strip()
        self._mode = "simulated"

        self._rng = random.Random()
        self._last_pick_ts = 0.0
        self._hold_seconds = 0.75
        self._last_infer_ts = 0.0
        self._infer_interval_s = max(0.0, float(os.environ.get("WASTE_INFER_INTERVAL_MS", "200")) / 1000.0)

        self._tflite_interpreter = None
        self._tflite_in = None
        self._tflite_out = None
        self._keras_model = None
        self._labels: Optional[list[str]] = None

        if not self.model_path:
            return

        try:
            if self.model_path.lower().endswith(".tflite"):
                self._init_tflite()
                self._mode = "tflite"
            elif self.model_path.lower().endswith((".h5", ".keras")):
                self._init_keras()
                self._mode = "keras"
        except Exception:
            # If anything fails, we keep simulated mode.
            self._mode = "simulated"

    @property
    def mode(self) -> str:
        return self._mode

    def predict(self, frame_bgr: np.ndarray, *, last: Optional[tuple[str, float]] = None) -> tuple[str, float]:
        """
        Return (category, confidence) in one of the 4 waste categories.
        """
        # Throttle inference for smooth laptop performance; reuse last prediction.
        now = time.time()
        if last is not None and self._infer_interval_s > 0 and (now - self._last_infer_ts) < self._infer_interval_s:
            return last[0], float(last[1])

        if self._mode == "tflite":
            try:
                pred = self._predict_tflite(frame_bgr)
                self._last_infer_ts = now
                return pred
            except Exception:
                self._mode = "simulated"

        if self._mode == "keras":
            try:
                pred = self._predict_keras(frame_bgr)
                self._last_infer_ts = now
                return pred
            except Exception:
                self._mode = "simulated"

        # Simulated fallback (stable for a short hold period).
        if last is None or (now - self._last_pick_ts) > self._hold_seconds:
            category = self._rng.choice(self.categories)
            confidence = self._rng.uniform(0.75, 0.99)
            self._last_pick_ts = now
            self._last_infer_ts = now
            return category, float(confidence)
        return last[0], float(last[1])

    def _init_tflite(self) -> None:
        Interpreter = None
        try:
            from tflite_runtime.interpreter import Interpreter as _I  # type: ignore

            Interpreter = _I
        except Exception:
            try:
                from tensorflow.lite.python.interpreter import Interpreter as _I  # type: ignore

                Interpreter = _I
            except Exception:
                Interpreter = None

        if Interpreter is None:
            raise RuntimeError("No TFLite interpreter available. Install `tensorflow` or `tflite-runtime`.")

        self._tflite_interpreter = Interpreter(model_path=self.model_path)
        self._tflite_interpreter.allocate_tensors()
        self._tflite_in = self._tflite_interpreter.get_input_details()[0]
        self._tflite_out = self._tflite_interpreter.get_output_details()[0]

        if self.labels_path and os.path.exists(self.labels_path):
            with open(self.labels_path, "r", encoding="utf-8") as f:
                self._labels = [line.strip() for line in f.read().splitlines() if line.strip()]

    def _predict_tflite(self, frame_bgr: np.ndarray) -> tuple[str, float]:
        assert self._tflite_interpreter is not None and self._tflite_in is not None and self._tflite_out is not None

        input_shape = self._tflite_in["shape"]
        h, w = int(input_shape[1]), int(input_shape[2])
        x = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        x = cv2.resize(x, (w, h), interpolation=cv2.INTER_AREA)
        x = np.expand_dims(x, axis=0)

        dtype = self._tflite_in["dtype"]
        if dtype == np.float32:
            x = (x.astype(np.float32) / 255.0).astype(np.float32)
        else:
            x = x.astype(dtype)

        self._tflite_interpreter.set_tensor(self._tflite_in["index"], x)
        self._tflite_interpreter.invoke()
        y = self._tflite_interpreter.get_tensor(self._tflite_out["index"])
        y = np.array(y).reshape(-1)

        idx = int(np.argmax(y))
        conf = float(y[idx])
        label = str(idx)
        if self._labels and 0 <= idx < len(self._labels):
            label = self._labels[idx]

        # If this is a common 6-class TrashNet-style model, map to 4 categories.
        if not self._labels and y.shape[0] == 6 and self.categories == ["Plastic", "Paper", "Metal", "Organic"]:
            trashnet_labels = ["cardboard", "glass", "metal", "paper", "plastic", "trash"]
            raw = trashnet_labels[idx]
            if raw in ("plastic",):
                return "Plastic", float(conf)
            if raw in ("paper",):
                return "Paper", float(conf)
            if raw in ("metal",):
                return "Metal", float(conf)
            # cardboard, glass, trash -> treat as Organic/other
            return "Organic", float(conf)

        mapped = _normalize_label(label)
        if mapped not in self.categories:
            mapped = self.categories[idx % len(self.categories)]
        return mapped, float(conf)

    def _init_keras(self) -> None:
        import tensorflow as tf  # type: ignore

        self._keras_model = tf.keras.models.load_model(self.model_path, compile=False)

    def _predict_keras(self, frame_bgr: np.ndarray) -> tuple[str, float]:
        assert self._keras_model is not None

        # Try to infer an image input size; fallback to 224x224 (Teachable Machine default).
        try:
            ishape = self._keras_model.inputs[0].shape
            h = int(ishape[1]) if ishape[1] is not None else 224
            w = int(ishape[2]) if ishape[2] is not None else 224
        except Exception:
            h, w = 224, 224

        x = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        x = cv2.resize(x, (w, h), interpolation=cv2.INTER_AREA)
        x = np.expand_dims(x, axis=0).astype(np.float32) / 255.0

        y = self._keras_model.predict(x, verbose=0)
        y = np.array(y).reshape(-1)
        idx = int(np.argmax(y))
        conf = float(y[idx])

        # If the model output size matches the known categories, use that directly.
        if y.shape[0] == len(self.categories):
            return self.categories[idx], float(conf)

        # Common 6-class TrashNet-style order: cardboard, glass, metal, paper, plastic, trash.
        if y.shape[0] == 6 and self.categories == ["Plastic", "Paper", "Metal", "Organic"]:
            trashnet_labels = ["cardboard", "glass", "metal", "paper", "plastic", "trash"]
            raw = trashnet_labels[idx]
            if raw in ("plastic",):
                return "Plastic", float(conf)
            if raw in ("paper",):
                return "Paper", float(conf)
            if raw in ("metal",):
                return "Metal", float(conf)
            return "Organic", float(conf)

        return self.categories[idx % len(self.categories)], float(conf)


class SmartWasteDetector:
    """
    Webcam-based waste detector.

    - Opens webcam using OpenCV
    - Uses a trained model if configured (TFLite or Keras); otherwise simulates
    - Draws the detected waste type on the frame
    - Exposes the last detected waste type to the main program
    """

    CATEGORIES = ["Plastic", "Paper", "Metal", "Organic"]

    def __init__(self, camera_index: int = 0, window_name: str = "Smart Waste Sorting System") -> None:
        self.window_name = window_name
        self._last: Optional[DetectionResult] = None
        self.classifier = WasteClassifier(self.CATEGORIES)

        self.cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
        if not self.cap.isOpened():
            self.cap.release()
            self.cap = cv2.VideoCapture(camera_index)

        if not self.cap.isOpened():
            raise RuntimeError("Could not open webcam (camera_index=0).")

    def release(self) -> None:
        try:
            self.cap.release()
        finally:
            try:
                cv2.destroyWindow(self.window_name)
            except Exception:
                pass

    def get_detected_waste_type(self) -> Optional[str]:
        """Return the latest detected waste type (or None if not detected yet)."""
        return None if self._last is None else self._last.category

    def read(self) -> DetectionResult:
        """
        Capture a frame from the webcam and return a DetectionResult.
        Uses a trained model if configured; otherwise simulates a prediction.
        """
        ok, frame = self.cap.read()
        if not ok or frame is None:
            time.sleep(0.03)
            raise RuntimeError("Could not read frame from webcam.")

        last = None if self._last is None else (self._last.category, self._last.confidence)
        category, confidence = self.classifier.predict(frame, last=last)

        annotated = self._annotate(frame, category=category, confidence=confidence)
        result = DetectionResult(
            category=category,
            confidence=float(confidence),
            annotated_frame=annotated,
            source=self.classifier.mode,
        )
        self._last = result
        return result

    def run_preview_loop(self) -> Optional[str]:
        """
        Display webcam feed with detection overlay.
        Press 'q' to quit. Returns the last detected waste type.
        """
        while True:
            result = self.read()
            cv2.imshow(self.window_name, result.annotated_frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
        last = self.get_detected_waste_type()
        self.release()
        return last

    def _annotate(self, frame_bgr: np.ndarray, *, category: str, confidence: float) -> np.ndarray:
        out = frame_bgr.copy()
        label = f"Detected: {category} ({confidence*100:.0f}%)"
        self._tag(out, label, (12, 34), scale=0.9, thickness=2)
        self._tag(out, f"Model: {self.classifier.mode}", (12, 66), scale=0.6, thickness=1)
        return out

    def _tag(
        self,
        frame_bgr: np.ndarray,
        text: str,
        org: tuple[int, int],
        *,
        scale: float,
        thickness: int,
    ) -> None:
        font = cv2.FONT_HERSHEY_SIMPLEX
        (tw, th), base = cv2.getTextSize(text, font, scale, thickness)
        x, y = org
        pad = 6
        cv2.rectangle(frame_bgr, (x - pad, y - th - pad), (x + tw + pad, y + base + pad), (0, 0, 0), -1)
        cv2.putText(frame_bgr, text, (x, y), font, scale, (255, 255, 255), thickness, cv2.LINE_AA)


if __name__ == "__main__":
    detector = SmartWasteDetector()
    waste_type = detector.run_preview_loop()
    print("Last detected waste type:", waste_type)

